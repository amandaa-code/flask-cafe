from flask import Flask, render_template, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    # Membaca menu dari file JSON
    import json
    with open('menu.json', 'r', encoding='utf-8') as file:
        menu_data = json.load(file)

    print(menu_data)
    return render_template('index.html', menu=menu_data)

if __name__ == '__main__':
    app.run(debug=True)
