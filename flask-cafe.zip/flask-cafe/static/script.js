// static/script.js
let orders = [];

document.querySelectorAll('.order-button').forEach(button => {
    button.addEventListener('click', (e) => {
        const name = e.target.getAttribute('data-name');
        const price = parseInt(e.target.getAttribute('data-price'));
        
        orders.push({ name, price });
        updateOrderSummary();
    });
});

function updateOrderSummary() {
    const orderList = document.getElementById('order-list');
    const totalPriceElement = document.getElementById('total-price');
    orderList.innerHTML = '';

    let total = 0;
    orders.forEach(order => {
        const li = document.createElement('li');
        li.textContent = `${order.name} - Rp ${order.price}`;
        orderList.appendChild(li);
        total += order.price;
    });

    totalPriceElement.textContent = `Rp ${total}`;
}

document.getElementById('checkout').addEventListener('click', () => {
    const payment = parseInt(document.getElementById('payment').value);
    const total = orders.reduce((sum, order) => sum + order.price, 0);
    const change = payment - total;

    if (change < 0) {
        alert('Uang yang diberikan kurang!');
    } else {
        document.getElementById('change-amount').textContent = `Rp ${change}`;
    }
});

